class ConfigError < StandardError

end