# No special settings required
require 'site_config' if File.exists?("#{RAILS_ROOT}/config/site_config.rb")
